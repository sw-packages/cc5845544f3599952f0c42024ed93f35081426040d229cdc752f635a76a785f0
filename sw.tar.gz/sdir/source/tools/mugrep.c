// Copyright (C) 2026 Artifex Software, Inc.
//
// This file is part of MuPDF.
//
// MuPDF is free software: you can redistribute it and/or modify it under the
// terms of the GNU Affero General Public License as published by the Free
// Software Foundation, either version 3 of the License, or (at your option)
// any later version.
//
// MuPDF is distributed in the hope that it will be useful, but WITHOUT ANY
// WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS
// FOR A PARTICULAR PURPOSE. See the GNU Affero General Public License for more
// details.
//
// You should have received a copy of the GNU Affero General Public License
// along with MuPDF. If not, see <https://www.gnu.org/licenses/agpl-3.0.en.html>
//
// Alternative licensing terms are available from the licensor.
// For commercial licensing, see <https://www.artifex.com/> or contact
// Artifex Software, Inc., 39 Mesa Street, Suite 108A, San Francisco,
// CA 94129, USA, for further information.

/*
 * mutool grep -- command line tool for searching in documents
 */

#include "mupdf/fitz.h"

#ifdef _WIN32
#include <io.h>
#define isatty _isatty
#else
#include <unistd.h>
#endif

static fz_context *ctx = NULL;
static fz_output *out = NULL;
static int show_page_number = 0;
static int show_file_name = 0;
static int search_backwards = 0;

static const char *mark_open = "";
static const char *mark_close = "";

static int mugrep_usage(void)
{
	fprintf(stderr,
		"usage: mugrep [options] pattern input.pdf [ input2.pdf ... ]\n"
		"\t-p -\tpassword for encrypted PDF files\n"
		"\t-F\tpattern is a fixed string\n"
		"\t-a\tignore accents (diacritics)\n"
		"\t-i\tignore case\n"
		"\t-H\tprint filename for each match\n"
		"\t-n\tprint page number for each match\n"
		"advanced options:\n"
		"\t-S\tcomma-separated list of search options\n"
		"\t-O\tcomma-separated list of stext options\n"
		"\t-b\tsearch pages in backwards order\n"
		"\t-[ -\tstart marker\n"
		"\t-] -\tend marker\n"
		"\t-v\tverbose\n"
		"\t-q\tquiet (don't print warnings and errors)\n"
		"\n"
	);
	fputs(fz_search_options_usage, stderr);
	fputs(fz_stext_options_usage, stderr);
	return EXIT_FAILURE;
}

/* Show every char between begin and end inclusive (i.e. begin_ch and end_ch are shown) */
static int
show_segment_inc(fz_stext_block *block, fz_stext_line *begin_line, fz_stext_char *begin_ch, fz_stext_line *end_line, fz_stext_char *end_ch, int *last)
{
	fz_stext_line *line;
	fz_stext_char *ch;

	/* If begin_ch != NULL, we are skipping, looking for a matching char.
	 * if begin_ch == NULL, we have met begin_ch already, and are now emitting.
	 * If end_line == NULL, we want to carry on to the end of the page. */

	while (block)
	{
		switch (block->type)
		{
		case FZ_STEXT_BLOCK_TEXT:
			for (line = block->u.t.first_line; line; line = line->next)
			{
				if (begin_line)
				{
					if (begin_line != line)
						continue;
					begin_line = NULL;
				}
				for (ch = line->first_char; ch; ch = ch->next)
				{
					if (begin_ch)
					{
						if (ch != begin_ch)
							continue;
						begin_ch = NULL;
					}
					if (ch->c < 32)
						fz_write_byte(ctx, out, ' ');
					else if (ch->c != 0xad)
						fz_write_rune(ctx, out, ch->c);
					*last = ch->c;
					if (ch == end_ch)
						return 1;
				}
				if (line == end_line)
					return 1;
				if (!fz_is_unicode_whitespace(*last) && *last != 0xad)
					fz_write_string(ctx, out, " ");
			}
			break;
		case FZ_STEXT_BLOCK_STRUCT:
			if (block->u.s.down)
			{
				if (show_segment_inc(block->u.s.down->first_block, begin_line, begin_ch, end_line, end_ch, last))
					return 1;
			}
			break;
		}
		block = block->next;
	}
	return 0;
}

/* Show every char between begin and end exclusive (i.e. begin_ch and end_ch themselves are not shown) */
static int
show_segment_ex(fz_stext_block *block, fz_stext_line *begin_line, fz_stext_char *begin_ch, fz_stext_line *end_line, fz_stext_char *end_ch, int *last)
{
	fz_stext_line *line;
	fz_stext_char *ch;

	/* If begin_ch != NULL, we are skipping, looking for a matching char.
	 * if begin_ch == NULL, we have met begin_ch already, and are now emitting.
	 * If end_line == NULL, we want to carry on to the end of the page. */

	while (block)
	{
		switch (block->type)
		{
		case FZ_STEXT_BLOCK_TEXT:
			for (line = block->u.t.first_line; line; line = line->next)
			{
				if (begin_line)
				{
					if (begin_line != line)
						continue;
					begin_line = NULL;
				}
				for (ch = line->first_char; ch; ch = ch->next)
				{
					if (ch == end_ch)
						return 1;
					if (begin_ch)
					{
						if (ch != begin_ch)
							continue;
						begin_ch = NULL;
						continue;
					}
					if (ch->c < 32)
						fz_write_byte(ctx, out, ' ');
					else if (ch->c != 0xad)
						fz_write_rune(ctx, out, ch->c);
					*last = ch->c;
				}
				if (line == end_line)
					return 1;
				if (!fz_is_unicode_whitespace(*last) && *last != 0xad)
					fz_write_string(ctx, out, " ");
			}
			break;
		case FZ_STEXT_BLOCK_STRUCT:
			if (block->u.s.down)
			{
				if (show_segment_ex(block->u.s.down->first_block, begin_line, begin_ch, end_line, end_ch, last))
					return 1;
			}
			break;
		}
		block = block->next;
	}
	return 0;
}

static void
show_match_snippet(char *file_name, int page_number, fz_stext_position begin, fz_stext_position end, fz_stext_position *prev_pos)
{
	int last = 0;
	int continuation = 0;

	if (prev_pos->page)
	{
		/* We are in the middle of showing a line. */
		if (begin.page == prev_pos->page && begin.block == prev_pos->block && begin.line == prev_pos->line)
		{
			/* We are part of the previous line. */
			continuation = 1;
		}
		else
		{
			/* We need to flush the rest of the previous line we were showing. */
			show_segment_ex(prev_pos->block, prev_pos->line, prev_pos->ch, prev_pos->line, NULL, &last);

			fz_write_byte(ctx, out, '\n');
		}
	}

	if (continuation)
	{
		/* Show the text between the end of the previous match, and the start of this one. */
		(void)show_segment_ex(prev_pos->block, prev_pos->line, prev_pos->ch, begin.line, begin.ch, &last);
	}
	else
	{
		if (show_file_name)
			fz_write_printf(ctx, out, "%s\t", file_name);
		if (show_page_number)
			fz_write_printf(ctx, out, "%d\t", page_number);

		/* Show the text from the start of the line to this match. */
		(void)show_segment_ex(begin.block, begin.line, NULL, begin.line, begin.ch, &last);
	}

	fz_write_string(ctx, out, mark_open);
	if (begin.page == end.page)
	{
		(void)show_segment_inc(begin.block, begin.line, begin.ch, end.line, end.ch, &last);
	}
	else
	{
		(void)show_segment_inc(begin.block, begin.line, begin.ch, NULL, NULL, &last);
		(void)show_segment_inc(end.page->first_block, NULL, NULL, end.line, end.ch, &last);
	}
	fz_write_string(ctx, out, mark_close);
	prev_pos->page = end.page;
	prev_pos->block = end.block;
	prev_pos->line = end.line;
	prev_pos->ch = end.ch;
}

static int
mugrep_run(char *filename, fz_document *doc, char *pattern, fz_search_options options, fz_stext_options *stext_options, int verbose)
{
	int page_count = fz_count_pages(ctx, doc);
	fz_search *search = NULL;
	fz_search_result res;
	int found = 0;
	fz_stext_position prev_pos = { 0 };

	fz_var(search);

	fz_try(ctx)
	{
		search = fz_new_search(ctx, pattern, options);

		if (search_backwards)
		{
			fz_stext_page *page = fz_new_stext_page_from_page_number(ctx, doc, page_count - 1, stext_options);
			fz_feed_search(ctx, search, page, page_count - 1);
		}
		else
		{
			fz_stext_page *page = fz_new_stext_page_from_page_number(ctx, doc, 0, stext_options);
			fz_feed_search(ctx, search, page, 0);
		}

		for (;;)
		{
			if (search_backwards)
				res = fz_search_backwards(ctx, search);
			else
				res = fz_search_forwards(ctx, search);
			if (res.reason == FZ_SEARCH_MATCH)
			{
				fz_search_match *details = res.u.match;

				found++;

				if (verbose)
				{
					printf("MATCH: %d quads (starting on page %d)\n", details->num_quads, details->quads[0].seq+1);
				}

				show_match_snippet(filename, details->num_quads > 0 ? (details->quads[0].seq + 1) : 0, details->begin, details->end, &prev_pos);
			}
			else if (res.reason == FZ_SEARCH_MORE_INPUT)
			{
				if (res.u.seq_needed < 0 || res.u.seq_needed >= page_count)
				{
					if (verbose)
						printf("FEEDING END\n");
					fz_feed_search(ctx, search, NULL, res.u.seq_needed);
				}
				else
				{
					int page_num = res.u.seq_needed;
					if (verbose)
						printf("FEEDING page %d\n", page_num);
					fz_stext_page *page = fz_new_stext_page_from_page_number(ctx, doc, page_num, stext_options);
					fz_feed_search(ctx, search, page, page_num);
				}
			}
			else if (res.reason == FZ_SEARCH_COMPLETE)
				break;
		}

		if (prev_pos.page)
		{
			int last;

			/* We need to flush the rest of the previous line we were showing. */
			show_segment_ex(prev_pos.block, prev_pos.line, prev_pos.ch, prev_pos.line, NULL, &last);

			fz_write_byte(ctx, out, '\n');
		}
	}
	fz_always(ctx)
		fz_drop_search(ctx, search);
	fz_catch(ctx)
		fz_rethrow(ctx);

	return found;
}

static void silence(void *user, const char *message) {}

int mugrep_main(int argc, char **argv)
{
	fz_document *doc = NULL;
	char *password = NULL; /* don't throw errors if encrypted */
	char *filename;
	char *pattern;
	int result = EXIT_FAILURE;
	int quiet = 0;
	int c;
	fz_search_options options = FZ_SEARCH_EXACT;
	fz_stext_options stext_options = { 0 };
	int verbose = 0;
	int is_fixed_string = 0;

	ctx = fz_new_context(NULL, NULL, FZ_STORE_UNLIMITED);
	if (!ctx)
	{
		fprintf(stderr, "cannot initialise context\n");
		exit(1);
	}

	fz_register_document_handlers(ctx);

	out = fz_stdout(ctx);

	if (isatty(1))
	{
		mark_open = "\x1b[1m";
		mark_close = "\x1b[0m";
	}

	fz_init_search_options(ctx, &options);

	while ((c = fz_getopt(argc, argv, "Faip:vO:S:nHb[:]:q")) != -1)
	{
		switch (c)
		{
		case 'O':
			fz_parse_stext_options(ctx, &stext_options, fz_optarg);
			break;
		case 'S':
			fz_parse_search_options(ctx, &options, fz_optarg);
			break;
		case 'F':
			is_fixed_string = 1;
			break;
		case 'a':
			options |= FZ_SEARCH_IGNORE_DIACRITICS;
			break;
		case 'i':
			options |= FZ_SEARCH_IGNORE_CASE;
			break;
		case 'p':
			password = fz_optarg;
			break;
		case 'n':
			show_page_number = 1;
			break;
		case 'H':
			show_file_name = 1;
			break;
		case 'b':
			search_backwards = 1;
			break;
		case 'v':
			verbose = 1;
			break;
		case 'q':
			quiet = 1;
			break;
		case '[':
			mark_open = mark_close = fz_optarg;
			break;
		case ']':
			mark_close = fz_optarg;
			break;
		default:
			return mugrep_usage();
		}
	}

	if (!is_fixed_string)
		options |= FZ_SEARCH_REGEXP | FZ_SEARCH_KEEP_PARAGRAPHS;

	if (quiet > 0)
	{
		fz_set_warning_callback(ctx, silence, NULL);
		fz_set_error_callback(ctx, silence, NULL);
	}

	if (fz_optind == argc)
		return mugrep_usage();

	pattern = argv[fz_optind++];

	fz_var(doc);

	fz_try(ctx)
	{
		while (fz_optind < argc)
		{
			filename = argv[fz_optind++];

			doc = fz_open_document(ctx, filename);
			if (fz_needs_password(ctx, doc))
				if (!fz_authenticate_password(ctx, doc, password))
				{
					fz_warn(ctx, "cannot authenticate password: %s", filename);
					fz_drop_document(ctx, doc);
					doc = NULL;
					continue;
				}

			if (mugrep_run(filename, doc, pattern, options, &stext_options, verbose))
				result = EXIT_SUCCESS;

			fz_drop_document(ctx, doc);
			doc = NULL;
		}
	}
	fz_always(ctx)
	{
		fz_drop_document(ctx, doc);
	}
	fz_catch(ctx)
	{
		fz_report_error(ctx);
		result = EXIT_FAILURE;
	}

	fz_drop_context(ctx);

	return result;
}
